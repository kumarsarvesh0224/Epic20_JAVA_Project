package com.example.employee_management_backend.service;



import com.example.employee_management_backend.model.Employee;
import com.example.employee_management_backend.repository.EmployeeRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    private final EmployeeRepository repository;

    public EmployeeServiceImpl(EmployeeRepository repository) {
        this.repository = repository;
    }

    @Override
    public Employee createEmployee(Employee employee) {
        employee.setId(UUID.randomUUID()); // AUTO ID
        return repository.save(employee);
    }

    @Override
    public List<Employee> getAllEmployees() {
        return repository.findAll();
    }

    @Override
    public Employee getEmployeeById(UUID id) {
        return repository.findById(id).orElse(null);
    }

    @Override
    public Employee updateEmployee(UUID id, Employee employee) {
        employee.setId(id);
        return repository.save(employee);
    }

    @Override
    public void deleteEmployee(UUID id) {
        repository.deleteById(id);
    }
}

package com.example.employee_management_backend.service;

import com.example.employee_management_backend.model.Employee;

import java.util.List;
import java.util.UUID;

public interface EmployeeService {
    Employee createEmployee(Employee employee);
    List<Employee> getAllEmployees();
    Employee getEmployeeById(UUID id);
    Employee updateEmployee(UUID id, Employee employee);
    void deleteEmployee(UUID id);
}

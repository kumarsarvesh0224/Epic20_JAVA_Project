import { useState } from "react";

export default function EmployeeList({ employees, onEdit, onDelete }) {
  const [expandedIds, setExpandedIds] = useState(new Set());

  const toggleDetails = (id) => {
    const newSet = new Set(expandedIds);
    if (newSet.has(id)) {
      newSet.delete(id);
    } else {
      newSet.add(id);
    }
    setExpandedIds(newSet);
  };

  return (
    <div className="employee-table-card">
      <h2>Employee List</h2>

      <table className="employee-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Actions</th>
          </tr>
        </thead>

        <tbody>
          {employees.length === 0 ? (
            <tr>
              <td colSpan="3" style={{ textAlign: "center" }}>
                No employees found
              </td>
            </tr>
          ) : (
            employees.map((emp) => (
              <>
                <tr key={emp.id}>
                  <td>{emp.id}</td>
                  <td>{emp.name}</td>
                  <td>
                    <button onClick={() => toggleDetails(emp.id)}>
                      {expandedIds.has(emp.id) ? "Hide Details" : "Show Details"}
                    </button>
                  </td>
                </tr>

                {expandedIds.has(emp.id) && (
                  <tr>
                    <td colSpan="3">
                      <div className="details-box">
                        <p><b>ID:</b> {emp.id}</p>
                        <p><b>Name:</b> {emp.name}</p>
                        <p><b>Email:</b> {emp.email}</p>
                        <p><b>Salary:</b> ₹ {emp.salary}</p>

                        <button onClick={() => onEdit(emp)}>Edit</button>
                        <button
                          style={{ marginLeft: "10px", background: "#e53935" }}
                          onClick={() => onDelete(emp.id)}
                        >
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                )}
              </>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

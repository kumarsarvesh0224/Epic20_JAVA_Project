import axios from "axios";

const API_URL = "http://localhost:8080/employees";

export const getEmployees = async () => {
  const res = await axios.get(API_URL);
  return res.data;
};

export const createEmployee = async (employee) => {
  return axios.post(API_URL, employee);
};

export const updateEmployee = async (employee) => {
  return axios.put(`${API_URL}/${employee.id}`, employee);
};

export const deleteEmployee = async (id) => {
  return axios.delete(`${API_URL}/${id}`);
};

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  getEmployees,
  createEmployee,
  updateEmployee,
  deleteEmployee
} from "./api/employeeApi";

import EmployeeForm from "./components/EmployeeForm";
import EmployeeList from "./components/EmployeeList";
import "./styles/App.css";

function App() {
  const queryClient = useQueryClient();
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [search, setSearch] = useState("");

  const { data: employees = [] } = useQuery({
    queryKey: ["employees"],
    queryFn: getEmployees
  });

  const createMutation = useMutation({
    mutationFn: createEmployee,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["employees"] })
  });

  const updateMutation = useMutation({
    mutationFn: updateEmployee,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["employees"] })
  });

  const deleteMutation = useMutation({
    mutationFn: deleteEmployee,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["employees"] })
  });

  const handleSubmit = (employee) => {
    if (selectedEmployee) {
      updateMutation.mutate({ ...employee, id: selectedEmployee.id });
    } else {
      createMutation.mutate(employee);
    }
  };

  const filteredEmployees = employees.filter(emp =>
    emp.name.toLowerCase().includes(search.toLowerCase()) ||
    emp.id.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="container">
      <h1>Employee Management Dashboard</h1>

      {/* Search */}
      <input
        className="search"
        placeholder="Search by ID or Name..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      {/* Dashboard layout: Form left, Table right */}
      <div className="dashboard">
        <EmployeeForm
          onSubmit={handleSubmit}
          selectedEmployee={selectedEmployee}
          clearSelection={() => setSelectedEmployee(null)}
        />

        <EmployeeList
          employees={filteredEmployees}
          onEdit={setSelectedEmployee}
          onDelete={(id) => deleteMutation.mutate(id)}
        />
      </div>
    </div>
  );
}

export default App;

import { useState, useEffect } from "react";

export default function EmployeeForm({ onSubmit, selectedEmployee, clearSelection }) {
  const [employee, setEmployee] = useState({
    name: "",
    email: "",
    salary: ""
  });

  // Populate form when editing
  useEffect(() => {
    if (selectedEmployee) {
      setEmployee({
        name: selectedEmployee.name,
        email: selectedEmployee.email,
        salary: selectedEmployee.salary
      });
    } else {
      setEmployee({ name: "", email: "", salary: "" });
    }
  }, [selectedEmployee]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setEmployee((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!employee.name || !employee.email || !employee.salary) {
      alert("Please fill all fields");
      return;
    }
    onSubmit(employee);
    setEmployee({ name: "", email: "", salary: "" });
    clearSelection();
  };

  const handleReset = () => {
    setEmployee({ name: "", email: "", salary: "" });
    clearSelection();
  };

  return (
    <form className="card" onSubmit={handleSubmit}>
      <h2>{selectedEmployee ? "Update Employee" : "Add New Employee"}</h2>

      <input
        type="text"
        name="name"
        placeholder="Name"
        value={employee.name}
        onChange={handleChange}
      />

      <input
        type="email"
        name="email"
        placeholder="Email"
        value={employee.email}
        onChange={handleChange}
      />

      <input
        type="number"
        name="salary"
        placeholder="Salary"
        value={employee.salary}
        onChange={handleChange}
      />

      {/* Buttons aligned using flex */}
      <div className="form-buttons">
        <button type="submit">{selectedEmployee ? "Update" : "Add"}</button>
        {selectedEmployee && (
          <button type="button" className="secondary" onClick={handleReset}>
            Cancel
          </button>
        )}
      </div>
    </form>
  );
}

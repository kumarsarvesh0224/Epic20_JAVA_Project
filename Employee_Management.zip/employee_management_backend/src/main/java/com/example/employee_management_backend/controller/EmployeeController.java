package com.example.employee_management_backend.controller;

import com.example.employee_management_backend.model.Employee;
import com.example.employee_management_backend.service.EmployeeService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@CrossOrigin(
        origins = "http://localhost:3000",
        allowedHeaders = "*",
        methods = {
                RequestMethod.GET,
                RequestMethod.POST,
                RequestMethod.PUT,
                RequestMethod.DELETE,
                RequestMethod.OPTIONS
        }
)
@RestController
@RequestMapping("/employees")
public class EmployeeController {

    private final EmployeeService service;

    // ✅ Constructor Injection (BEST PRACTICE)
    public EmployeeController(EmployeeService service) {
        this.service = service;
    }

    // ✅ CREATE Employee
    @PostMapping
    public Employee create(@RequestBody Employee employee) {
        return service.createEmployee(employee);
    }

    // ✅ READ All Employees
    @GetMapping
    public List<Employee> getAll() {
        return service.getAllEmployees();
    }

    // ✅ READ Employee By ID
    @GetMapping("/{id}")
    public Employee getById(@PathVariable UUID id) {
        return service.getEmployeeById(id);
    }

    // ✅ UPDATE Employee
    @PutMapping("/{id}")
    public Employee update(
            @PathVariable UUID id,
            @RequestBody Employee employee) {

        employee.setId(id); // 🔥 IMPORTANT
        return service.updateEmployee(id, employee);
    }

    // ✅ DELETE Employee
    @DeleteMapping("/{id}")
    public void delete(@PathVariable UUID id) {
        service.deleteEmployee(id);
    }
}

package com.example.employee_management_backend.model;

import lombok.*;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Table("employee")
public class Employee {

    @PrimaryKey
    private UUID id;

    private String name;
    private String email;
    private Double salary;
}
